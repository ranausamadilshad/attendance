import React from 'react'

const UpdateLeaveAdmin = () => {
    return (
        <>
            
        </>
    )
}

export default UpdateLeaveAdmin
