import React from 'react'
import LeaveSettingScreen from './LeaveSettingScreen'

const LeaveSetting = () => {
    return (
        <>
           <LeaveSettingScreen/> 
        </>
    )
}

export default LeaveSetting
