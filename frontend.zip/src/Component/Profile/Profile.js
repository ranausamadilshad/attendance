import React from 'react'
import ProfileScreen from './ProfileScreen'

const Profile = () => {
    return (
        <>
          <ProfileScreen/>  
        </>
    )
}

export default Profile
