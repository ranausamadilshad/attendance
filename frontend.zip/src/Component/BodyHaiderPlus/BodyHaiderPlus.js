import React from 'react'
import BodyHaiderScreenPlus from './BodyHaiderPlusScreen'

const BodyHaiderPlus = (props) => {
    return (
        <>
         <BodyHaiderScreenPlus main={props.main} cname={props.cname} btnName={props.btnName} btnlink={props.btnlink}/>   
        </>
    )
}

export default BodyHaiderPlus
