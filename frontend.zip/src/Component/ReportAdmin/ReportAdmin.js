import React from 'react'
import ReportAdminScreen from './ReportAdminScreen'

const ReportAdmin = () => {
    return (
        <>
        <ReportAdminScreen/>    
        </>
    )
}

export default ReportAdmin
