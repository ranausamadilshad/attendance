import React from 'react'
import Login from '../Component/Login/Login';

const LoginPage = () => {
    return (
        <>
         <Login/>   
        </>
    )
}

export default LoginPage
