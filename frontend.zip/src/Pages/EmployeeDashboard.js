import React from 'react'

const EmployeeDashboard = () => {
    return (
        <>
            EmployeeDashboard
        </>
    )
}

export default EmployeeDashboard
