import React from 'react'
import AdminHeader from '../Component/AdminHeader/AdminHeader';


const ReportEmployeePage = () => {
    return (
        <>
                  <AdminHeader main='Report' cname="Employee"/>
        </>
    )
}

export default ReportEmployeePage
