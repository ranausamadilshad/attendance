import React from 'react'

const ViewDevicePage = () => {
    return (
        <>
            View Device
        </>
    )
}

export default ViewDevicePage
