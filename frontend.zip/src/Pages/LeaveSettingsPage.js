import React from 'react';

const LeaveSettingsPage = () => {
    return (
        <>
            Hello LeaveSettingsPage
        </>
    )
}

export default LeaveSettingsPage
