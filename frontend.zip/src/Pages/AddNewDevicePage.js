import React from 'react';

const AddNewDevicePage = () => {
    return (
        <>
        Add New Device   
        </>
    )
}

export default AddNewDevicePage;
